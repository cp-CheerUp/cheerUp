package com.codepresso.cheerup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheerupApplicationTests {

	@Test
	void contextLoads() {
	}

}
