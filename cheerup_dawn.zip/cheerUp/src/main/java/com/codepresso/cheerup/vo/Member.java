package com.codepresso.cheerup.vo;

public class Member {
}
