package com.codepresso.cheerup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheerupApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheerupApplication.class, args);
	}

}
